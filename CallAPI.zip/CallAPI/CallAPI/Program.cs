﻿using System;
using System.IO;
using System.Net.Http;

namespace CallAPI
{
    class Program
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        static void Main(string[] args)
        {
            string exeDir = AppDomain.CurrentDomain.BaseDirectory;
            logger.Info("path:" + exeDir);
            string line;
            //Month
            logger.Info("Month");
            if (DateTime.Now.Day.ToString() == "1")
                try
                {
                    StreamReader sr = new StreamReader(exeDir + "/MonthUrl.txt");
                    line = sr.ReadLine();
                    logger.Info("line:" + line);
                    sr.Close();
                    try
                    {
                        HttpClient httpClient = new HttpClient();
                        HttpResponseMessage httpResponseMessage = httpClient.GetAsync(line).Result;

                        int statusCode = (int)httpResponseMessage.StatusCode;
                        logger.Info($"Http 狀態碼: {statusCode}");

                        string content = httpResponseMessage.Content.ReadAsStringAsync().Result;
                        logger.Info($"Http 回應內容: {content}");
                    }
                    catch (Exception e)
                    {
                        logger.Error("發生錯誤:" + e.ToString());
                    }
                }
                catch (Exception e)
                {
                    logger.Error("Exception: " + e.Message);
                }
            //Day
            logger.Info("Day");
            try
            {
                StreamReader sr = new StreamReader(exeDir + "/DayUrl.txt");
                line = sr.ReadLine();
                logger.Info("line:" + line);
                sr.Close();
                try
                {
                    HttpClient httpClient = new HttpClient();
                    HttpResponseMessage httpResponseMessage = httpClient.GetAsync(line).Result;

                    int statusCode = (int)httpResponseMessage.StatusCode;
                    logger.Info($"Http 狀態碼: {statusCode}");

                    string content = httpResponseMessage.Content.ReadAsStringAsync().Result;
                    logger.Info($"Http 回應內容: {content}");
                }
                catch (Exception e)
                {
                    logger.Error("發生錯誤:" + e.ToString());
                }
            }
            catch (Exception e)
            {
                logger.Error("Exception: " + e.Message);
            }
        }
    }
}
